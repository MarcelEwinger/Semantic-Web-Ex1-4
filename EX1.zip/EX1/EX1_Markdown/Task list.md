**Task list EX1 Marcel Ewinger**

- [x] Task 1
- [x] Task 2
- [x] Task 3
- [x] Task 4
- [x] Task 5
- [x] Task 6
- [] Task 7
- [] Task 8
- [] Task 9
- [] Task 10
- [] Task 11